# Prism Calc — Android starter project

Native Android calculator built with Kotlin + Jetpack Compose.

## Project identity
- App name: Prism Calc
- Application ID: `com.prismcalc.app`
- Version: 1.0.0 (versionCode 1)
- minSdk: 23
- compileSdk / targetSdk: 36

## Current milestone
- Premium light glossy interface
- Basic arithmetic: +, −, ×, ÷
- Expression evaluation with parentheses support
- Live result preview for valid expressions
- Clear, delete, sign toggle and percent-to-fraction shortcut
- Calculation history dialog (in-memory for this milestone)
- Copy a history entry
- GitHub Actions workflow to build a debug APK in the cloud

## Cloud build from a phone
1. Create a GitHub repository named `PrismCalc`.
2. Extract this ZIP on your phone.
3. In the repository website, use Add file > Upload files and upload the extracted project contents, including the hidden `.github` folder. If the phone file picker hides hidden folders, create `.github/workflows/android-build.yml` using Add file > Create new file and paste the workflow from this project.
4. Commit the files to the `main` branch.
5. Open the repository's Actions tab and select `Prism Calc Android Build`.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, download the `prism-calc-debug-apk` artifact, extract it on your phone, and install the APK for testing.

## Build details
- JDK 17
- Android SDK Platform 36
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- Internet required for first dependency download

## Important
This is a development build, not a Play Store release. History is currently in memory and resets when the app process is closed. Scientific and finance tools, converters, persistent storage, accessibility testing, signing and Play Store assets remain planned.

## Release checklist
- Confirm final app name and unique application ID before first release.
- Create and securely back up an upload key. Never share it.
- Build a signed Android App Bundle (AAB), not only a debug APK.
- Complete Play Console Data safety, content rating, app access and privacy policy declarations truthfully.
- Provide a public privacy policy URL that matches actual app and SDK behaviour.
- Test release builds on real devices before production rollout.
