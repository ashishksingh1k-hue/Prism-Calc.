package com.prismcalc.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import net.objecthunter.exp4j.ExpressionBuilder
import java.text.DecimalFormat

private val Ink = Color(0xFF1C2940)
private val Muted = Color(0xFF8794A8)
private val Blue = Color(0xFF557DF5)
private val Violet = Color(0xFF9277F6)
private val Canvas = Color(0xFFF4F7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(244, 247, 255)
        window.navigationBarColor = android.graphics.Color.rgb(244, 247, 255)
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent { PrismCalcApp() }
    }
}

@Composable
fun PrismCalcApp() {
    val context = LocalContext.current
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("0") }
    var error by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(listOf<String>()) }

    val keys = listOf(
        listOf("AC", "⌫", "%", "÷"),
        listOf("7", "8", "9", "×"),
        listOf("4", "5", "6", "−"),
        listOf("1", "2", "3", "+"),
        listOf("±", "0", ".", "=")
    )

    fun evaluate(input: String): Double {
        val normalized = input.replace("×", "*").replace("÷", "/").replace("−", "-")
        return ExpressionBuilder(normalized).build().evaluate()
    }

    fun calculate() {
        if (expression.isBlank()) return
        try {
            val value = evaluate(expression)
            if (!value.isFinite()) throw ArithmeticException("Not finite")
            val formatted = DecimalFormat("#,##0.########").format(value)
            result = formatted
            history = (listOf("$expression = $formatted") + history).distinct().take(50)
            error = false
        } catch (_: Exception) {
            result = "Invalid expression"
            error = true
        }
    }

    fun press(key: String) {
        when (key) {
            "AC" -> { expression = ""; result = "0"; error = false }
            "⌫" -> { if (expression.isNotEmpty()) expression = expression.dropLast(1) }
            "=" -> calculate()
            "±" -> {
                if (expression.isNotEmpty()) expression = "-($expression)"
            }
            "%" -> {
                if (expression.isNotEmpty()) expression += "/100"
            }
            else -> {
                expression += key
                error = false
                try {
                    val v = evaluate(expression)
                    if (v.isFinite()) result = DecimalFormat("#,##0.########").format(v)
                } catch (_: Exception) { }
            }
        }
    }

    if (showHistory) {
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text("Calculation history", color = Ink, fontWeight = FontWeight.Bold) },
            text = {
                if (history.isEmpty()) {
                    Text("Your completed calculations will appear here.", color = Muted)
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                        items(history) { item ->
                            Row(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val left = item.substringBefore(" = ")
                                    expression = left
                                    showHistory = false
                                    calculate()
                                }.padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(item, color = Ink, modifier = Modifier.weight(1f), fontSize = 14.sp)
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy",
                                    tint = Blue, modifier = Modifier.size(18.dp).clickable {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Prism Calc result", item))
                                        Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                                    })
                            }
                            HorizontalDivider(color = Color(0xFFE8EDFA))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistory = false }) { Text("Close", color = Blue) }
            },
            dismissButton = {
                TextButton(onClick = { history = emptyList() }) { Text("Clear", color = Color(0xFFE35B70)) }
            },
            containerColor = Color.White
        )
    }

    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFFF9FBFF), Canvas, Color(0xFFEAF0FF)))
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier.size(44.dp).shadow(8.dp, RoundedCornerShape(15.dp))
                        .background(Brush.linearGradient(listOf(Blue, Violet)), RoundedCornerShape(15.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("P", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Prism Calc", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("SMART • SIMPLE • BEAUTIFUL", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                }
                IconButton(onClick = { showHistory = true }) {
                    Icon(Icons.Default.History, contentDescription = "History", tint = Blue)
                }
            }

            Column(
                modifier = Modifier.weight(1f).fillMaxWidth()
                    .shadow(12.dp, RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(listOf(Color.White, Color(0xFFF7F9FF))),
                        RoundedCornerShape(28.dp)
                    )
                    .border(1.dp, Color.White, RoundedCornerShape(28.dp))
                    .padding(22.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.End
            ) {
                Text("YOUR CALCULATION", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(16.dp))
                Text(expression.ifBlank { "0" }, color = Muted, fontSize = 25.sp,
                    textAlign = TextAlign.End, maxLines = 2)
                Spacer(Modifier.height(12.dp))
                Text(result, color = if (error) Color(0xFFE35B70) else Ink,
                    fontSize = if (result.length > 12) 30.sp else 42.sp,
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.End, maxLines = 2)
            }

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                keys.forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { key ->
                            val special = key in listOf("AC", "⌫", "%", "÷", "×", "−", "+")
                            val equals = key == "="
                            val bg = when {
                                equals -> Brush.linearGradient(listOf(Blue, Violet))
                                special -> Brush.linearGradient(listOf(Color(0xFFE9EEFF), Color.White))
                                else -> Brush.linearGradient(listOf(Color.White, Color(0xFFF4F7FF)))
                            }
                            Box(
                                modifier = Modifier.weight(1f).height(64.dp)
                                    .shadow(if (equals) 9.dp else 5.dp, RoundedCornerShape(20.dp))
                                    .background(bg, RoundedCornerShape(20.dp))
                                    .border(1.dp, if (special) Color(0xFFDDE5FF) else Color.White, RoundedCornerShape(20.dp))
                                    .clickable { press(key) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (key == "⌫") {
                                    Icon(Icons.Default.Backspace, contentDescription = "Delete",
                                        tint = Blue, modifier = Modifier.size(22.dp))
                                } else {
                                    Text(key, color = if (equals) Color.White else if (special) Blue else Ink,
                                        fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
            Text("PRISM CALC  •  VERSION 1.0", color = Muted, fontSize = 9.sp,
                letterSpacing = 1.5.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
}
